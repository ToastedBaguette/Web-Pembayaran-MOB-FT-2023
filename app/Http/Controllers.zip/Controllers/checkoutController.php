<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;

class checkoutController extends Controller
{
    function checkout(Request $request){
        date_default_timezone_set('Asia/Jakarta');
        $size = ['S','M','L',"XL","XXL",'3XL', '4XL'];
        $user = Auth::user();
        $ukuran = $request->get("size-picker");
        if(!in_array($ukuran,$size)){
            return redirect()->route('dashboard');
        }
        $nama = $user->name;
        $id = $user->id;
        $nrp = $user->nrp;
        $nrp = substr($nrp, 3);
        $orderID = 'INV-'.date('d').date('m').date('y')."-".$nrp."-".$id."-".$ukuran;
        $count = DB::table('transaksi')->where('order_id', 'like', "%".$orderID."%")->count();
        $orderID = $orderID."-".$count;

        // return 'INV-'.date('d').date('m').date('y')."-".$nrp."-".$id."-".$ukuran;

        //MULAI MITRANS
        \Midtrans\Config::$serverKey = env('SERVER_KEY');
        // Set to Development/Sandbox Environment (default). Set to true for Production Environment (accept real transaction).
        \Midtrans\Config::$isProduction = true;
        // Set sanitization on (default)
        \Midtrans\Config::$isSanitized = true;
        // Set 3DS transaction for credit card to true
        \Midtrans\Config::$is3ds = false;
        
        $params = array(
            'transaction_details' => array(
                'order_id' => $orderID
            ),
            'item_details' => array([
                "id"       => $ukuran,
                "price"    => 1000,
                'quantity' => 1,
                "name"     => 'Baju MOBFT 2022 ukuran: '.$ukuran
            ]),
            'customer_details' => array(
                'first_name' => $user->name,
                'email' => $user->email ,
                'phone' => $user->nomor_telpon,
            ),
        );
        
        $snapToken = \Midtrans\Snap::getSnapToken($params);
        
        return view('layouts.checkout',['snapToken'=>$snapToken,'name'=>$nama,'ukuran'=>$ukuran,'orderID'=>$orderID]);

        //return view('layouts.checkout');
        
    }
    
}

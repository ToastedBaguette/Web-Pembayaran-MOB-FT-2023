<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;

class dashboardController extends Controller
{
    function index(){
        $user = Auth::user();
        $count = DB::table('transaksi')->where('users_id', $user->id)->count();
        $status = "";
        $orderId = "";
        if($count == 0){
            $status = "false";
        }
        else{
            $order = DB::table('transaksi')->where('users_id', $user->id)->orderBy('id', "desc")->get();
            $status = $order[0]->transaction_status;
            if($status =='expire' || $status == 'deny' || $status=='cancel'){
                $status = "gagal";
            }
            elseif($status =='settlement' || $status == 'capture'){
                $status = "sukses";
            }
            else if($status == 'pending'){
                $status = "pending";
            }
            
            $orderId = $order[0]->order_id;
        }
        return view('layouts.dashboard', compact('user', 'status', 'orderId'));
    }

    
}

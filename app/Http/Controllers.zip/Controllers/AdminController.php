<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Gate;

class AdminController extends Controller
{
    function index()
    {
        $query = DB::table('users')
            ->join('transaksi', 'users.id', '=', 'transaksi.users_id')
            ->get();
        $data = array();

        foreach ($query as $temp) {
            $nama = $temp->name;
            $nrp = $temp->nrp;
            $telpon = $temp->nomor_telpon;
            $orderId = "";
            $trannsactionTime = "";
            $status = "";
            $settlementTime = "";
            $paymentType = "";
            $vaNumber = "";
            if (isset($temp->order_id)) {
                $orderId = $temp->order_id;
                $trannsactionTime = $temp->transaction_time;
                $status = $temp->transaction_status;
                if ($status == 'expire' || $status == 'deny' || $status == 'cancel') {
                    $status = "gagal";
                } elseif ($status == 'settlement' || $status == 'capture') {
                    $status = "sukses";
                } else if ($status == 'pending') {
                    $status = "pending";
                }
                $settlementTime = $temp->settlement_time;
                if($temp->payment_type == "bank_transfer" || $temp->payment_type == "echannel"){
                    $paymentType = $temp->bank;
                    $vaNumber = $temp->va_number;
                }
                else{
                    $paymentType = $temp->payment_type;
                }
            }
            $temp2 = [
                "nama"=>$nama,
                "nrp"=>$nrp,
                "telpon"=>$telpon,
                "order_id"=>$orderId,
                "transaction_time"=>$trannsactionTime,
                "status"=>$status,
                "settlement_time"=>$settlementTime,
                "payment_type"=>$paymentType,
                "va_number"=>$vaNumber
            ];
            array_push($data, $temp2);
        }
        return view('layouts.admin', compact('data'));
    }
}

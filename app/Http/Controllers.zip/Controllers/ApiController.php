<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use PhpParser\Node\Stmt\Return_;

class ApiController extends Controller
{
    public function midtransHandle(Request $request){
        $json = json_decode($request->getContent());
        $status = $json->transaction_status;
        if($status == 'pending'){
            $order_id = $json->order_id;
            $users_id = explode('-', $order_id)[3];
            $ukuran = explode('-', $order_id)[4];
            $payment_type = $json->payment_type;
            $va_number = "";
            $bank = "";
            $issuer = "";

            if($payment_type == "qris"){
                $issuer = $json->issuer;
            }
            else if($payment_type == "bank_transfer"){
                if(isset($json->permata_va_number)){
                    $va_number = $json->permata_va_number;
                    $bank = "permata";
                }
                else{
                    foreach ($json->va_numbers as $vn){
                        $va_number = $vn->va_number; 
                        $bank = $vn->bank;
                    }
                }
            }
            else if($payment_type == "echannel"){
                $va_number = $json->bill_key;
                $bank = "mandiri";
            }

            $insert = [
                "users_id"=>$users_id,
                "transaction_id"=>$json->transaction_id,
                "transaction_time"=>$json->transaction_time,
                "transaction_status"=>$json->transaction_status,
                "status_message"=>$json->status_message,
                "status_code"=>$json->status_code,
                "signature_key"=>$json->signature_key,
                "payment_type"=>$payment_type,
                "va_number"=>$va_number,
                "bank"=>$bank,
                "issuer"=>$issuer,
                "order_id"=>$order_id,
                "gross_amount"=>$json->gross_amount,
                "fraud_status"=>$json->fraud_status
            ];

            DB::table('transaksi')->insert($insert);
            DB::table('users')->where('id', $users_id)->update(['ukuran'=>$ukuran]);
        }
        else if($status =='expire' || $status == 'deny' || $status=='cancel'){
            $userid = explode('-',$json->order_id);
            $order = DB::table('transaksi')->where('users_id',$userid[3])->get();
            $signature_key = hash('sha512',$order[0]->order_id.$json->status_code.$order[0]->gross_amount.env('SERVER_KEY'));
            if($signature_key == $json->signature_key){
                DB::table('users')->where('id',$userid[3])->update(['ukuran'=>null]);
                DB::table('transaksi')->where('order_id',$json->order_id)->update(['transaction_status'=>$json->transaction_status]);
            }
            else{
                return abort(404);
            }
        }
        else if($status =='settlement' || $status = 'capture'){
            $userid = explode('-',$json->order_id);
            $order = DB::table('transaksi')->where('users_id',$userid[3])->get();
            $signature_key = hash('sha512',$order[0]->order_id.$json->status_code.$order[0]->gross_amount.env('SERVER_KEY'));
            if($signature_key == $json->signature_key){
               DB::table('transaksi')->where('users_id',$userid[3])->update(['transaction_status'=>$json->transaction_status,'settlement_time'=> $json->settlement_time]);
            }
            else{
                return abort(404);
            }
        }
        
        return 1;
    }
}
